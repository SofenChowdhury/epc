<p>Confirm the task is completed?</p>
<div class="modal-footer">
	<button type="button" class="btn btn-default waves-effect " data-dismiss="modal">Close</button>
	<a href="{{url('confirmTask/'.$id)}}" class="text-light"><button type="button" class="btn btn-primary waves-effect waves-light ">Yes</button></a>
</div>